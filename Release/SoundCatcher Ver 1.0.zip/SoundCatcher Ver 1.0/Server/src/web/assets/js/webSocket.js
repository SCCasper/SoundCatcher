var socket;

socket = new WebSocket("ws://172.24.1.1:80");
socket.binaryType = 'arraybuffer';

socket.onopen = function(event) {

};
socket.onerror = function(event) {
	
};

socket.onmessage = function(msg) {
	postMessage(msg.data);
};
