﻿# SoundCatcher
### 담당교수님
- 황기태 교수님 <br/>

### 구성원
- 최지훈 : Streaming Server 설계 및 구현
- 권영재 : Streaming Web Server 설계 및 구현
- 심영보 : Raspberry Pi 환경 및 네트워크 환경 구축
- 유민석 : Client & Ui 설계 및 구현

- [동영상](https://youtu.be/h2jTrTSD1wQ)
